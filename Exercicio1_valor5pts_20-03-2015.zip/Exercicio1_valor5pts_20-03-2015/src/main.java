
public class main {
	
	public static void main(String[] args){
		
		carro carro1 = new carro();
		carro1.setNome_do_cliente("Maria");
		
		carro1.setQuilometros_por_litro(9);
		
		carro1.verifica_se_carro_economico();
		
		moto moto1 = new moto();
		moto1.setQuilometros_por_litro(20);
		moto1.verifica_se_carro_economico();
		
		moto1.setCilindradas(150);
		moto1.verifica_se_moto_potente();
					
	}
}
		


