
public class carro extends veiculo {
	
	private int quatro_portas;
	private String banco_de_couro;
	private String ar_condicionado;
	private Boolean portas_abertas;
	public int getQuatro_portas() {
		return quatro_portas;
	}
	public void setQuatro_portas(int quatro_portas) {
		this.quatro_portas = quatro_portas;
	}
	public String getBanco_de_couro() {
		return banco_de_couro;
	}
	public void setBanco_de_couro(String banco_de_couro) {
		this.banco_de_couro = banco_de_couro;
	}
	public String getAr_condicionado() {
		return ar_condicionado;
	}
	public void setAr_condicionado(String ar_condicionado) {
		this.ar_condicionado = ar_condicionado;
	}
	public Boolean getPortas_abertas() {
		return portas_abertas;
	}
	public void setPortas_abertas(Boolean portas_abertas) {
		this.portas_abertas = portas_abertas;
	}
	
	
	
}


